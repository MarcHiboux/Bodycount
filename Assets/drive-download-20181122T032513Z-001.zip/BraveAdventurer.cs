﻿using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using UnityEngine;
using UnityEngine.UI;

public class BraveAdventurer : MonoBehaviour {

    public InputField nom;


    class Adventurer   
    {
        int kills, downed, death, assist;
        public string name, title;
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void CreateAdventurer()
    {
        Adventurer GreenHorn = new Adventurer();
        GreenHorn.name = nom.text.ToString();
        nom.text = "";
    }
}
